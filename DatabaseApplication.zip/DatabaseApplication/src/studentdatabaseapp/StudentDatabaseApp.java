package studentdatabaseapp;

import java.util.Scanner;

public class StudentDatabaseApp {

	public static void main(String[] args) {
		
		
		// Ask how many students you want to add
		System.out.println("Enter Number of new Students to Enroll: ");
		Scanner in = new Scanner(System.in);
		int numOfStudents = in.nextInt();
		// creating array of datatype student of length = number
		Student[] students = new Student[numOfStudents];
		
		
		// Create a number for new Students
		for(int n= 0; n<numOfStudents;n++) {

			students[n]  = new Student();
			students[n].enroll();
			students[n].payTution();
			

		}
		
		System.out.println(students[0].showInfoStr());
		System.out.println(students[1].showInfoStr());
		System.out.println(students[2].showInfoStr());
		
		

	}

}
