package studentdatabaseapp;

import java.util.Scanner;

public class Student {
	
	private String firstName;
	private String lastName;
	private String studentId;
	private int gradeYear;
	private String courses = "";
	private int tutionBalance = 0;
	private static int costOfCourse = 600; 
	private static int id = 1000;
	
	
	// Constuctor: Prompt user to enter Student name and year
	public Student() {
		Scanner in = new Scanner(System.in);
		System.out.print("Enter Student First Name: ");
		this.firstName = in.nextLine();
		
		System.out.print("Enter Student Last Name: ");
		this.lastName = in.nextLine();
		
		System.out.print("1 - Freshman\n2 - Sophmore\n3 - Junior\n4 - Senior\nEnter Student Class Level: ");
		this.gradeYear = in.nextInt();
		
		// setting student id
		setStudentId();
		
//		System.out.println(firstName + " "+ lastName+" "+ gradeYear+ " "+ studentId);
		
	}
	
	// Generate an ID
	private void setStudentId() {
		// Grade level  + ID 
		id++;
		
		this.studentId = gradeYear +""+ id;
	}
	
	
	// Enroll in Courses
	public void enroll() {
		// Get inside a loop , user hits 0
		do {
			System.out.println("Enter Course to Enroll (Q to Quit): ");
			Scanner in = new Scanner(System.in);
			String course  = in.nextLine();
			if ( course.equalsIgnoreCase("Q")) {
				break;
			}
			else {
				courses = courses +"\n  "+ course ;
				tutionBalance = tutionBalance + costOfCourse;
			}
		}while(true);
		
//		System.out.println("ENROLLED IN: "+ courses);
//		System.out.println("TUTION BALANCE: "+tutionBalance);
	}
	
	// View Balance 
	public void viewBalance() {
		System.out.println("Your Balance is: $"+ tutionBalance);
		
	}

	// Pay Tution
	public void payTution() {
		viewBalance();
		System.out.println("Enter Your Payment: $");
		
		Scanner in = new Scanner(System.in);
		int payment = in.nextInt();
		
		tutionBalance = tutionBalance-payment;
		
		System.out.println("Thank You For Your Payment of $"+ payment);
		viewBalance();
		
	}
	
	// Show Status
	public String showInfoStr() {
		return "Name: "+ firstName+" "+lastName+ 
				"\nGrade Level: "+gradeYear +
				"\nCourses Enrolled: "+ courses + 
				"\nYour Current Balance is : "+ tutionBalance;
	}
	
	
}
